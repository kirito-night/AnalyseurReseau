package Couches;

public interface ICouches {
	String analyse();
}
