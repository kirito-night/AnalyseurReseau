télécharger le AnalyseurReseau.jar fournit 
lancer le ficiher  AnalyseurReseau.jar avec la commande : java -jar  AnalyseurReseau.jar
une fenêtre va appraitre et qui demande de sélectionner une trame
cliquez sur File -> Open
choisissez le fichier .txt qui contient votre trame à analyser
cliquez sur une trame afficher dans la liste des trames
	-dans la fenêtre en-bas à gauche apparaitra le trame brut(qui a filtré tous ce qui n'est pas des octets) 
	-dans la fenêtre en-bas à droite apparaitra les résultats des analyses 
pour ouvrir un autre fichier .txt, cliquez sur open à nouveau et répétez le processu ci-dessus
pour sauvegarder les résultats d'analyse des trames contenus dans votre fichier .txt
	-Cliquez sur File -> Save  choisir l'emplacement où vous souhaitez de sauvegarder le fichier .txt qui contient les résultats
pour quitter l'application
	-Cliquez sur File -> Quit
	-Ou cliquez sur le croix en haut à droite


